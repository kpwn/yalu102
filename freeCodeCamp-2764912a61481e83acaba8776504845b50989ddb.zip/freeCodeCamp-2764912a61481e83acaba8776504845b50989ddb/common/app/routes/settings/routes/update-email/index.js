import UpdateEmail from './Update-Email.jsx';

export default function updateEmailRoute() {
  return {
    path: 'update-email',
    component: UpdateEmail
  };
}
