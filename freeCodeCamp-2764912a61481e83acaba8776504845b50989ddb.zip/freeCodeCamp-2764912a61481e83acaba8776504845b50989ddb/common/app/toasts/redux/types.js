import createTypes from '../../utils/create-types';

export default createTypes([
  'makeToast',
  'removeToast'
], 'toast');
